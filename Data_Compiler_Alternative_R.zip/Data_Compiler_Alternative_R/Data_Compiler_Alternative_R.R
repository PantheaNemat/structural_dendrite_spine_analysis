############################################################################################################################################################################
#### DATA SET GENERATION
## Data set geneation is based on output saved in subfolders from IMARIS
# Clear existing workspace objects
rm(list = ls())
graphics.off()


## SPINE DENSITY
# Set working directory to where the data file is located & results should be saved (change to your own directory)
setwd("~/Documents/Data/AllS/SpineDensity")

# create a list of the files from your target directory

file_list <- list.files(path = "~/Documents/Data/AllS/SpineDensity")

# initiate a blank data frame, each iteration of the loop will append the data from the given file to this variable
rawdata <- data.frame()

# had to specify columns to get rid of the total column
for (i in 1:length(file_list)) {
  temp_data <- read_csv(file_list[i], col_select = 1, col_names = FALSE, skip = 4) # each file will be read in, specify which columns you need read in to avoid any errors
  
  temp_data$animal <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[2]
  }) # clean the data as needed, in this case I am creating a new column that indicates which file each row of data came from
  temp_data$slice <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[3]
  })
  temp_data$side <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[4]
  })
  temp_data$layer <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[6]
  })
  temp_data$cell_type <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[9]
  })
  
  rawdata <- rbind(rawdata, temp_data) # for each iteration, bind the new data to the building dataset
}

colnames(rawdata)[1] <- "spine_density"

# Set working directory to where the data file is located & results should be saved (change to your own directory)
setwd("~/Documents/Protocol Paper")
overview <- read.table("Exp10_Overview.csv", sep = ",", dec = ".", header = TRUE)
overview <- overview[, -c(3)]

df <- merge(overview, rawdata, by = "animal", all = TRUE)


write.table(df,
            file = "SpineDensity_Data.csv",
            sep = ";", dec = ",", row.names = F
)





### SPINE CLUSTER ANALYSIS
### important to use Attachment Pt Distance (NOT ORIGIN, it's the origin from the IMARIS volume 0/0/0)
rm(list = ls())
graphics.off()

options(scipen = 100, digits = 4)

# Set working directory to where the data file is located & results should be saved (change to your own directory)
# setwd("~/Documents/Protocol Paper/Data/Spine Density")
setwd("~/Documents/Data/AllS/SpineAttachment")

# create a list of the files from your target directory
# file_list <- list.files(path="~/Documents/Protocol Paper/Data/Spine Density")
file_list <- list.files(path = "~/Documents/Data/AllS/SpineAttachment")

# initiate a blank data frame, each iteration of the loop will append the data from the given file to this variable
rawdata <- data.frame()

# had to specify columns to get rid of the total column
for (i in 1:length(file_list)) {
  temp_data <- read_csv(file_list[i], col_select = 1, col_names = FALSE, skip = 4) # each file will be read in, specify which columns you need read in to avoid any errors
  
  temp_data$animal <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[2]
  }) # clean the data as needed, in this case I am creating a new column that indicates which file each row of data came from
  temp_data$slice <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[3]
  })
  temp_data$side <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[4]
  })
  temp_data$layer <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[6]
  })
  temp_data$cell_type <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[9]
  })
  
  rawdata <- rbind(rawdata, temp_data) # for each iteration, bind the new data to the building dataset
}

colnames(rawdata)[1] <- "spine_attachment"


# initiate a blank data frame, each iteration of the loop will append the data from the given file to this variable
rawdata2 <- data.frame()

# had to specify columns to get rid of the total column
for (i in 1:length(file_list)) {
  temp_data <- read_csv(file_list[i], col_select = 7, col_names = FALSE, skip = 4) # each file will be read in, specify which columns you need read in to avoid any errors
  
  temp_data$animal <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[2]
  }) # clean the data as needed, in this case I am creating a new column that indicates which file each row of data came from
  temp_data$slice <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[3]
  })
  temp_data$side <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[4]
  })
  temp_data$layer <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[6]
  })
  temp_data$cell_type <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[9]
  })
  
  rawdata2 <- rbind(rawdata2, temp_data) # for each iteration, bind the new data to the building dataset
}

colnames(rawdata2)[1] <- "dendrite_number"

# Set working directory to where the data file is located & results should be saved (change to your own directory)
setwd("~/Documents/Data/AllS/SpineAttachmentPtDiameter")

# create a list of the files from your target directory
file_list <- list.files(path = "~/Documents/Data/AllS/SpineAttachmentPtDiameter")

# initiate a blank data frame, each iteration of the loop will append the data from the given file to this variable
rawdata3 <- data.frame()

# had to specify columns to get rid of the total column
for (i in 1:length(file_list)) {
  temp_data <- read_csv(file_list[i], col_select = 1, col_names = FALSE, skip = 4) # each file will be read in, specify which columns you need read in to avoid any errors
  
  temp_data$animal <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[2]
  }) # clean the data as needed, in this case I am creating a new column that indicates which file each row of data came from
  temp_data$slice <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[3]
  })
  temp_data$side <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[4]
  })
  temp_data$layer <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[6]
  })
  temp_data$cell_type <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[9]
  })
  
  rawdata3 <- rbind(rawdata3, temp_data) # for each iteration, bind the new data to the building dataset
}

colnames(rawdata3)[1] <- "spine_attachment_diameter"

rawdata_all <- cbind(rawdata, rawdata2)
rawdata_all <- cbind(rawdata_all, rawdata3)
rawdata_all <- rawdata_all[, -c(2:6, 8:12)]
rawdata_all$dendrite_identifier <- paste(rawdata_all$dendrite_number, rawdata_all$animal, rawdata_all$slice, rawdata_all$side, rawdata_all$layer, rawdata_all$cell_type, sep = "_")


# Set working directory to where the data file is located & results should be saved (change to your own directory)
setwd("~/Documents/Data/AllS/DendriteLength")

# create a list of the files from your target directory
file_list <- list.files(path = "~/Documents/Data/AllS/DendriteLength")

# initiate a blank data frame, each iteration of the loop will append the data from the given file to this variable
rawdata4 <- data.frame()

# had to specify columns to get rid of the total column
for (i in 1:length(file_list)) {
  temp_data <- read_csv(file_list[i], col_select = 1, col_names = FALSE, skip = 4) # each file will be read in, specify which columns you need read in to avoid any errors
  
  temp_data$animal <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[2]
  }) # clean the data as needed, in this case I am creating a new column that indicates which file each row of data came from
  temp_data$slice <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[3]
  })
  temp_data$side <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[4]
  })
  temp_data$layer <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[6]
  })
  temp_data$cell_type <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[9]
  })
  
  rawdata4 <- rbind(rawdata4, temp_data) # for each iteration, bind the new data to the building dataset
}

colnames(rawdata4)[1] <- "dendrite_length"

# initiate a blank data frame, each iteration of the loop will append the data from the given file to this variable
rawdata5 <- data.frame()

# had to specify columns to get rid of the total column
for (i in 1:length(file_list)) {
  temp_data <- read_csv(file_list[i], col_select = 7, col_names = FALSE, skip = 4) # each file will be read in, specify which columns you need read in to avoid any errors
  
  temp_data$animal <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[2]
  }) # clean the data as needed, in this case I am creating a new column that indicates which file each row of data came from
  temp_data$slice <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[3]
  })
  temp_data$side <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[4]
  })
  temp_data$layer <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[6]
  })
  temp_data$cell_type <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[9]
  })
  
  rawdata5 <- rbind(rawdata5, temp_data) # for each iteration, bind the new data to the building dataset
}

colnames(rawdata5)[1] <- "dendrite_number"

n_occur <- data.frame(table(rawdata_dendrite_all$dendrite_identifier))
n_occur[n_occur$Freq > 1,] #each dendrite identifier should only occur once, otherwise data isn't merged correctly, if this is the case, find reason why in your data

rawdata_dendrite_all <- cbind(rawdata4, rawdata5)
rawdata_dendrite_all <- rawdata_dendrite_all[, -c(2:6)]
rawdata_dendrite_all$dendrite_identifier <- paste(rawdata_dendrite_all$dendrite_number, rawdata_dendrite_all$animal, rawdata_dendrite_all$slice, rawdata_dendrite_all$side, rawdata_dendrite_all$layer, rawdata_dendrite_all$cell_type, sep = "_")

prep <- merge(rawdata_all, rawdata_dendrite_all, by = c("dendrite_identifier","dendrite_number", "animal", "slice", "side", "layer", "cell_type"))


# Set working directory to where the data file is located & results should be saved (change to your own directory)
setwd("~/Documents/Protocol Paper")
overview <- read.table("Exp10_Overview.csv", sep = ";", dec = ",", header = TRUE)
overview <- overview[, -c(3)]

df <- merge(overview, prep, by = "animal", all = TRUE)

write.table(df,
            file = "SpineAttachment_Data.csv",
            sep = ";", dec = ",", row.names = F
)






############################################################################################################################################################################
#### DATA SET GENERATION
## Data set geneation is based on output saved in subfolders from IMARIS
# Clear existing workspace objects
rm(list = ls())
graphics.off()

options(scipen = 100, digits = 4)

## SPINE VOLUME
# Set working directory to where the data file is located & results should be saved (change to your own directory)
setwd("~/Documents/Data/SelS/Spine Volume")

# Create a list of the files from your target directory
file_list <- list.files(path = "~/Documents/Data/SelS/Spine Volume")

# Initiate a blank data frame, each iteration of the loop will append the data from the given file to this variable
rawdata <- data.frame()

# For loop to read in each file in your folder and to append each file into one big data set
for (i in 1:length(file_list)) {
  temp_data <- read_csv(file_list[i], col_select = 1, col_names = FALSE, skip = 4) # Each file will be read in, specify which column contains values of interest
  
  # Add ID to values to be able to trace data back to source file
  # ID is based on individual parts of file name + contains additional variables
  temp_data$animal <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[2]
  })
  temp_data$slice <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[3]
  })
  temp_data$side <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[4]
  })
  temp_data$layer <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[6]
  })
  temp_data$cell_type <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[9]
  })
  
  # for each iteration, bind the new data to the building data set
  rawdata <- rbind(rawdata, temp_data)
}

# Assign variable name to values in new data set
colnames(rawdata)[1] <- "spine_volume"

# Assign more specific name to data frame
volume <- rawdata

# initiate a blank data frame, each iteration of the loop will append the data from the given file to this variable
rawdata <- data.frame()

# had to specify columns to get rid of the total column
for (i in 1:length(file_list)) {
  temp_data <- read_csv(file_list[i], col_select = 7, col_names = FALSE, skip = 4) # each file will be read in, specify which columns you need read in to avoid any errors
  
  temp_data$animal <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[2]
  }) # clean the data as needed, in this case I am creating a new column that indicates which file each row of data came from
  temp_data$slice <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[3]
  })
  temp_data$side <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[4]
  })
  temp_data$layer <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[6]
  })
  temp_data$cell_type <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[9]
  })
  
  rawdata <- rbind(rawdata, temp_data) # for each iteration, bind the new data to the building dataset
}

colnames(rawdata)[1] <- "dendrite_number"

# Assign more specific name to data frame
dendritenumber <- rawdata


## Repeat previous steps for each variable of interest

## SPINE VOLUME HEAD
# Set working directory to where the data file is located & results should be saved (change to your own directory)
setwd("~/Documents/Data/SelS/Spine Volume Head")

# Create a list of the files from your target directory
file_list <- list.files(path = "~/Documents/Data/SelS/Spine Volume Head")

rawdata <- data.frame()

for (i in 1:length(file_list)) {
  temp_data <- read_csv(file_list[i], col_select = 1, col_names = FALSE, skip = 4)
  
  temp_data$animal <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[2]
  })
  temp_data$slice <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[3]
  })
  temp_data$side <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[4]
  })
  temp_data$layer <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[6]
  })
  temp_data$cell_type <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[9]
  })
  
  rawdata <- rbind(rawdata, temp_data)
}

colnames(rawdata)[1] <- "spine_volume_head"

volumehead <- rawdata

## SPINE VOLUME NECK
# Set working directory to where the data file is located & results should be saved (change to your own directory)
setwd("~/Documents/Spine Volume Neck")

# Create a list of the files from your target directory
file_list <- list.files(path = "~/Documents/Spine Volume Neck")

rawdata <- data.frame()

for (i in 1:length(file_list)) {
  temp_data <- read_csv(file_list[i], col_select = 1, col_names = FALSE, skip = 4)
  
  temp_data$animal <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[2]
  })
  temp_data$slice <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[3]
  })
  temp_data$side <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[4]
  })
  temp_data$layer <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[6]
  })
  temp_data$cell_type <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[9]
  })
  
  rawdata <- rbind(rawdata, temp_data)
}

colnames(rawdata)[1] <- "spine_volume_neck"

volumeneck <- rawdata


## SPINE MAXIMUM HEAD DIAMETER
# Set working directory to where the data file is located & results should be saved (change to your own directory)
setwd("~/Documents/Spine Max Diameter Head")

# Create a list of the files from your target directory
file_list <- list.files(path = "~/Documents/Data/SelS/Spine Max Diameter Head")

rawdata <- data.frame()

for (i in 1:length(file_list)) {
  temp_data <- read_csv(file_list[i], col_select = 1, col_names = FALSE, skip = 4)
  
  temp_data$animal <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[2]
  })
  temp_data$slice <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[3]
  })
  temp_data$side <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[4]
  })
  temp_data$layer <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[6]
  })
  temp_data$cell_type <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[9]
  })
  
  rawdata <- rbind(rawdata, temp_data)
}

colnames(rawdata)[1] <- "spine_max_head"

head <- rawdata

## SPINE MAXIMUM NECK DIAMETER
# Set working directory to where the data file is located & results should be saved (change to your own directory)
setwd("~/Documents/ Data/SelS/Spine Max Diameter Neck")

# Create a list of the files from your target directory
file_list <- list.files(path = "~/Documents/Data/SelS/Spine Max Diameter Neck")

rawdata <- data.frame()

for (i in 1:length(file_list)) {
  temp_data <- read_csv(file_list[i], col_select = 1, col_names = FALSE, skip = 4)
  
  temp_data$animal <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[2]
  })
  temp_data$slice <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[3]
  })
  temp_data$side <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[4]
  })
  temp_data$layer <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[6]
  })
  temp_data$cell_type <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[9]
  })
  
  rawdata <- rbind(rawdata, temp_data)
}

colnames(rawdata)[1] <- "spine_max_neck"

neck <- rawdata

## SPINE LENGTH
# Set working directory to where the data file is located & results should be saved (change to your own directory)
setwd("~/Documents/Data/SelS/Spine Length")

# Create a list of the files from your target directory
file_list <- list.files(path = "~/Documents/Data/SelS/Spine Length")

rawdata <- data.frame()

for (i in 1:length(file_list)) {
  temp_data <- read_csv(file_list[i], col_select = 1, col_names = FALSE, skip = 4)
  
  temp_data$animal <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[2]
  })
  temp_data$slice <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[3]
  })
  temp_data$side <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[4]
  })
  temp_data$layer <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[6]
  })
  temp_data$cell_type <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[9]
  })
  
  rawdata <- rbind(rawdata, temp_data)
}

colnames(rawdata)[1] <- "spine_length"

length <- rawdata

### SPINE MEAN HEAD DIAMETER
# Set working directory to where the data file is located & results should be saved (change to your own directory)
setwd("~/Documents/Data/SelS/Spine Mean Diameter Head")

# Create a list of the files from your target directory
file_list <- list.files(path = "~/Documents/Data/SelS/Spine Mean Diameter Head")

rawdata <- data.frame()

for (i in 1:length(file_list)) {
  temp_data <- read_csv(file_list[i], col_select = 1, col_names = FALSE, skip = 4)
  
  temp_data$animal <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[2]
  })
  temp_data$slice <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[3]
  })
  temp_data$side <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[4]
  })
  temp_data$layer <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[6]
  })
  temp_data$cell_type <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[9]
  })
  
  rawdata <- rbind(rawdata, temp_data)
}

colnames(rawdata)[1] <- "spine_mean_head"

spine_mean_head <- rawdata


### SPINE MEAN NECK DIAMETER
# Set working directory to where the data file is located & results should be saved (change to your own directory)
setwd("~/Documents/Data/SelS/Spine Mean Diameter Neck")

# Create a list of the files from your target directory
file_list <- list.files(path = "~/Documents/Data/SelS/Spine Mean Diameter Neck")

rawdata <- data.frame()

for (i in 1:length(file_list)) {
  temp_data <- read_csv(file_list[i], col_select = 1, col_names = FALSE, skip = 4)
  
  temp_data$animal <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[2]
  })
  temp_data$slice <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[3]
  })
  temp_data$side <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[4]
  })
  temp_data$layer <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[6]
  })
  temp_data$cell_type <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[9]
  })
  
  rawdata <- rbind(rawdata, temp_data)
}

colnames(rawdata)[1] <- "spine_mean_neck"

spine_mean_neck <- rawdata


## SPINE MAXIMUM INTENSITY IN CHANNEL 2 (eGRASP SIGNAL)
# Set working directory to where the data file is located & results should be saved (change to your own directory)
setwd("~/Documents/Data/SelS/Spine Intensity Ch=2")

# Create a list of the files from your target directory
file_list <- list.files(path = "~/Documents/Data/SelS/Spine Intensity Ch=2")

rawdata <- data.frame()

for (i in 1:length(file_list)) {
  temp_data <- read_csv(file_list[i], col_select = 1, col_names = FALSE, skip = 4)
  
  temp_data$animal <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[2]
  })
  temp_data$slice <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[3]
  })
  temp_data$side <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[4]
  })
  temp_data$layer <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[6]
  })
  temp_data$cell_type <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[9]
  })
  
  rawdata <- rbind(rawdata, temp_data)
}

colnames(rawdata)[1] <- "spine_inten_ch2"

spine_inten_ch2 <- rawdata


## SPINE MAXIMUM INTENSITY IN CHANNEL 3 (RFP SIGNAL)
# Set working directory to where the data file is located & results should be saved (change to your own directory)
setwd("~/Documents/Data/SelS/Spine Intensity Ch=3")

# Create a list of the files from your target directory
file_list <- list.files(path = "~/Documents/Data/SelS/Spine Intensity Ch=3")

rawdata <- data.frame()

for (i in 1:length(file_list)) {
  temp_data <- read_csv(file_list[i], col_select = 1, col_names = FALSE, skip = 4)
  
  temp_data$animal <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[2]
  })
  temp_data$slice <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[3]
  })
  temp_data$side <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[4]
  })
  temp_data$layer <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[6]
  })
  temp_data$cell_type <- sapply(strsplit(gsub(".csv", "", file_list[i]), "_"), function(x) {
    x[9]
  })
  
  rawdata <- rbind(rawdata, temp_data)
}

colnames(rawdata)[1] <- "spine_inten_ch3"

spine_inten_ch3 <- rawdata


### Combine all created data frames into one data frame
# All data frames based on the same subjects so that they can be bound by their ID and are equally long
rawdata_all <- cbind(head, neck)
rawdata_all <- cbind(rawdata_all, length)
rawdata_all <- cbind(rawdata_all, spine_mean_head)
rawdata_all <- cbind(rawdata_all, spine_mean_neck)
rawdata_all <- cbind(rawdata_all, spine_inten_ch2)
rawdata_all <- cbind(rawdata_all, spine_inten_ch3)
rawdata_all <- cbind(rawdata_all, volume)
rawdata_all <- cbind(rawdata_all, volumehead)
rawdata_all <- cbind(rawdata_all, volumeneck)
rawdata_all <- cbind(rawdata_all, dendritenumber)

rawdata_all <- rawdata_all[, -c(2:6, 8:12, 14:18, 20:24, 26:30, 32:36, 38:42, 44:48, 50:54, 56:60)] # Delete redundant columns

# Set working directory to where overview file is located & results should be saved (change to your own directory)
setwd("~/Documents/Protocol Paper")
overview <- read.table("Exp10_Overview.csv", sep = ";", dec = ",", header = TRUE)
overview <- overview[, -c(3)]

# Merge data frame with overview file
df <- merge(overview, rawdata_all, by = "animal", all = TRUE)

# Save data frame for later analysis
write.table(df,
            file = "SpineMorph_Data.csv",
            sep = ";", dec = ",", row.names = F
)